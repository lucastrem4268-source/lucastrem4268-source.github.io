# SignalDesk

**Incident coordination workspace — an engineering portfolio project by Lucas Ferreira.**

SignalDesk models how a team records, assigns, investigates and resolves service incidents. It emphasizes explicit business rules and data consistency, rather than simulated dashboards alone.

![Architecture](architecture.svg)

## Try it

Requires Node.js **24.x**. No third-party dependencies or installation step.

```sh
npm test
npm start
# http://localhost:4180
```

The default server binds to **127.0.0.1**. It is a local engineering demo, not a public production service. SQLite files are created in `data/`, ignored by Git. Back up the database using SQLite-aware tooling before changes; do not edit the JSON snapshot manually.

The portfolio version works on GitHub Pages via browser storage. It shares the exact domain module with the backend. Only localhost:4180 activates the API adapter. Opening the HTML with file:// is not supported because it uses ES modules; use an HTTP server.

## Working features

- Incident lifecycle: **open → investigating → monitoring → resolved**.
- Owner assignment required before starting investigation.
- A meaningful update is required for each state transition. Resolved incidents are read-only.
- Optional signal key prevents another active incident for the same service/signal.
- Timeline records each accepted action with timestamp and a declared actor label.
- Catalog of services and example reliability targets. Service health is **derived from active incident severity**, not uptime probes.
- Metrics computed from recorded timestamps: active incidents, unresolved SEV1, mean time to acknowledgment and mean time to resolution. Metrics include **all stored records**, not a rolling period. MTTR means creation to resolution here; it is not a measure of verified downtime.
- Search, severity/status filters, all-record CSV export, light/dark themes and English/Portuguese.
- SQLite transactions, optimistic concurrency checks, persistent request idempotency, and SSE invalidation events.

## Architecture and tradeoffs

```mermaid
flowchart LR
  UI[Browser interface] --> A{Storage adapter}
  A -->|GitHub Pages| L[LocalStorage + Web Locks]
  A -->|Local Node server| API[HTTP commands API]
  API --> D[Shared domain rules]
  L --> D
  API --> SQL[(SQLite transaction)]
  SQL --> S[Versioned state snapshot]
  SQL --> K[Idempotency ledger]
  API -->|Committed revision via SSE| UI
```

Domain transitions are pure and immutable. A single transaction writes the new snapshot, audit events and idempotency record together. Revision mismatches return **409**, requiring review of refreshed state. Failed commands roll back all writes. A repeated key with the same payload returns current state with `duplicate: true`; a changed payload with that key is rejected. This is intentionally not a cached replay of the original HTTP response.

The UI retries a failed transport once with the **same key and payload**. The backend persists that key across restarts. SSE announces a revision; clients fetch the state rather than applying partial events. Reconnection receives the current revision. Browser mode uses Web Locks when available and refreshes on storage events; without Web Locks, cross-tab writes are best-effort.

SQLite stores one versioned JSON snapshot plus a relational idempotency ledger. This keeps the implementation small and transaction boundaries visible, but reads and writes scale with the complete state. It is **not event sourcing**, and the in-document audit log is not tamper-proof. For larger workloads, normalize incidents and events, add indexed queries and cursor pagination, and define retention for the ledger.

## HTTP contract

| Endpoint | Purpose |
| --- | --- |
| `GET /api/health` | Storage mode and current revision |
| `GET /api/state` | Full state snapshot |
| `POST /api/commands` | Validated domain command |
| `GET /api/events` | SSE stream of revision notifications |

Example command (revision must match the current GET response):

```http
POST /api/commands
Content-Type: application/json
Idempotency-Key: example-request-0001

{
  "revision": 0,
  "command": {
    "type": "create",
    "actor": "Demo operator",
    "service": "identity",
    "title": "Identity requests exceeding timeout",
    "severity": "SEV1",
    "signal": "identity-timeout"
  }
}
```

Other commands:

```json
{"type":"assign","id":"INC-...","owner":"Alex Morgan","actor":"Demo operator"}
{"type":"transition","id":"INC-...","status":"investigating","message":"Investigating database connections.","actor":"Demo operator"}
{"type":"note","id":"INC-...","message":"Checking the latest deployment.","actor":"Demo operator"}
```

Errors: 400 invalid JSON, 403 cross-origin browser request, 404 unknown route/incident, 409 revision/transition/duplicate conflict, 413 body over 16 KiB, 415 unsupported content type, 422 invalid fields. Static server uses an allowlist and does not serve database or server source files.

## Verification

`npm test` uses Node's test runner for domain and actual HTTP integration tests. Cases include immutable transitions, owner requirements, duplicate signals, CSV escaping, concurrent writes, retry deduplication, transaction rollback, malformed inputs, static file allowlisting, database restart and SSE notifications. It does not represent production load testing or a browser accessibility audit.

## Deliberate boundaries

All people, service names, incidents and metric values are fictional examples. No relationship with Google or any employer is implied. Actor labels and owners are **user-entered text, not authenticated identities**. This version has no RBAC, account management, live probes, email/Slack/PagerDuty delivery, paging schedules, multi-tenancy or external integrations. Production hosting requires authentication/authorization, TLS, CSRF/session protections appropriate to that auth model, rate limits, database normalization, backups, monitoring and deployment hardening.

The server is single-process, synchronous SQLite, intended for small local demos. There is no retention/pagination yet; do not ingest unbounded records. Do not deploy its writable endpoints publicly as-is.

## Why this project

It demonstrates API design, concurrency, durable transactions, domain modeling, integration tests and a responsive interface. The incident workflow is inspired by public [Google SRE incident response material](https://sre.google/workbook/incident-response/); it is an educational implementation, not a Google product or a claim of production experience.

## Português

Central de incidentes com frontend bilíngue e backend local Node.js/SQLite. Demonstra regras de negócio, transações, idempotência, controle de alterações concorrentes, histórico e eventos SSE. Para executar: Node 24, `npm test` e `npm start`. A versão no GitHub Pages funciona somente no navegador. Esta é uma implementação de portfólio com dados fictícios, sem monitoramento real ou autenticação de usuários.
