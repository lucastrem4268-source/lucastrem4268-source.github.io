export class DomainError extends Error { constructor(message,status=422){super(message);this.status=status;} }
const text=(v,min,max,label)=>{if(typeof v!=='string'||v.trim().length<min||v.trim().length>max)throw new DomainError(`${label}: ${min}–${max} characters required`);return v.trim();};
export const stages=['open','investigating','monitoring','resolved'];
export function seed(now=Date.now()){
 const at=m=>new Date(now-m*60000).toISOString();
 const services=[{id:'api',name:'API Gateway',team:'Platform',region:'us-east-1',target:99.9},{id:'checkout',name:'Checkout',team:'Commerce',region:'eu-west-1',target:99.95},{id:'identity',name:'Identity',team:'Security',region:'global',target:99.99},{id:'queue',name:'Event Queue',team:'Platform',region:'us-east-1',target:99.9}];
 const incidents=[{id:'INC-1042',service:'api',title:'Elevated latency on gateway requests',severity:'SEV1',status:'investigating',owner:'Alex Morgan',createdAt:at(38),acknowledgedAt:at(34),resolvedAt:null,summary:'Investigating connection pool saturation.',signal:'gateway-latency'},{id:'INC-1041',service:'checkout',title:'Checkout retries above threshold',severity:'SEV2',status:'monitoring',owner:'Sam Taylor',createdAt:at(76),acknowledgedAt:at(69),resolvedAt:null,summary:'Retry configuration adjusted. Watching recovery.',signal:'checkout-retries'},{id:'INC-1040',service:'queue',title:'Consumer backlog after deployment',severity:'SEV2',status:'resolved',owner:'Jordan Lee',createdAt:at(260),acknowledgedAt:at(255),resolvedAt:at(205),summary:'Consumer concurrency restored after rollback.',signal:'queue-backlog'}];
 const events=incidents.flatMap(i=>[{id:i.id+'-created',incident:i.id,at:i.createdAt,actor:'Demo seed',kind:'created',message:i.title},{id:i.id+'-updated',incident:i.id,at:i.resolvedAt||i.acknowledgedAt,actor:i.owner,kind:i.status,message:i.summary}]);
 return {revision:0,services,incidents,events};
}
export function applyCommand(state,command,now=Date.now(),newId=()=>crypto.randomUUID()){
 if(!command||typeof command!=='object'||Array.isArray(command))throw new DomainError('Command must be an object');
 const actor=text(command.actor,2,60,'Actor');const next=structuredClone(state);const at=new Date(now).toISOString();let incident,kind,message;
 if(command.type==='create'){
  const service=next.services.find(s=>s.id===command.service);if(!service)throw new DomainError('Unknown service');
  const title=text(command.title,8,140,'Title');if(!['SEV1','SEV2','SEV3'].includes(command.severity))throw new DomainError('Invalid severity');
  const signal=command.signal?text(command.signal,2,100,'Signal key'):'';
  if(signal&&next.incidents.some(i=>i.status!=='resolved'&&i.service===service.id&&i.signal===signal))throw new DomainError('An active incident already exists for this signal',409);
  incident={id:'INC-'+newId(),service:service.id,title,severity:command.severity,status:'open',owner:'',createdAt:at,acknowledgedAt:null,resolvedAt:null,summary:'',signal};next.incidents.unshift(incident);kind='created';message=title;
 }else{
  incident=next.incidents.find(i=>i.id===command.id);if(!incident)throw new DomainError('Incident not found',404);
  if(command.type==='assign'){
   if(incident.status==='resolved')throw new DomainError('Resolved incidents are read-only',409);
   incident.owner=text(command.owner,2,60,'Owner');kind='assigned';message=incident.owner;
  }else if(command.type==='transition'){
   const index=stages.indexOf(incident.status);if(index<0||index>=stages.length-1||!stages.includes(command.status)||command.status!==stages[index+1])throw new DomainError('Invalid state transition',409);
   if(!incident.owner)throw new DomainError('Assign an owner before advancing');
   message=text(command.message,8,1200,'Update');incident.status=command.status;incident.summary=message;kind=command.status;
   if(command.status==='investigating')incident.acknowledgedAt=at;
   if(command.status==='resolved')incident.resolvedAt=at;
  }else if(command.type==='note'){
   if(incident.status==='resolved')throw new DomainError('Resolved incidents are read-only',409);
   message=text(command.message,3,1200,'Note');kind='note';
  }else throw new DomainError('Unknown command');
 }
 next.revision++;next.events.push({id:newId(),incident:incident.id,at,actor,kind,message});return next;
}
export function metrics(state){const ack=state.incidents.filter(i=>i.acknowledgedAt),resolved=state.incidents.filter(i=>i.resolvedAt);const mean=values=>values.length?Math.round(values.reduce((a,b)=>a+b,0)/values.length/60000):null;return{active:state.incidents.filter(i=>i.status!=='resolved').length,severe:state.incidents.filter(i=>i.status!=='resolved'&&i.severity==='SEV1').length,mtta:mean(ack.map(i=>new Date(i.acknowledgedAt)-new Date(i.createdAt))),mttr:mean(resolved.map(i=>new Date(i.resolvedAt)-new Date(i.createdAt)))};}
export function csv(state){const cell=v=>'"'+String(v??'').replace(/^[=+@\-\t\r]/,"'$&").replaceAll('"','""')+'"';return [['ID','Service','Title','Severity','Status','Owner','Created','Resolved'],...state.incidents.map(i=>[i.id,i.service,i.title,i.severity,i.status,i.owner,i.createdAt,i.resolvedAt])].map(r=>r.map(cell).join(',')).join('\r\n');}
