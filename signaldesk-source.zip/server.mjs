import http from 'node:http';import {DatabaseSync} from 'node:sqlite';import {createHash,randomUUID} from 'node:crypto';import {readFileSync,mkdirSync} from 'node:fs';import {fileURLToPath,pathToFileURL} from 'node:url';import path from 'node:path';import {applyCommand,seed,DomainError} from './domain.js';
export function createApp({database=':memory:'}={}){
 const db=new DatabaseSync(database);db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; CREATE TABLE IF NOT EXISTS state(id INTEGER PRIMARY KEY CHECK(id=1), document TEXT NOT NULL); CREATE TABLE IF NOT EXISTS requests(key TEXT PRIMARY KEY, hash TEXT NOT NULL, revision INTEGER NOT NULL);');
 if(!db.prepare('SELECT id FROM state WHERE id=1').get())db.prepare('INSERT INTO state VALUES(1,?)').run(JSON.stringify(seed()));
 const read=()=>JSON.parse(db.prepare('SELECT document FROM state WHERE id=1').get().document);const clients=new Set();const root=path.dirname(fileURLToPath(import.meta.url));
 const send=(res,status,body)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(body));};
 const server=http.createServer(async(req,res)=>{
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','same-origin');
  try{
   const url=new URL(req.url,'http://localhost');
   if(url.pathname.startsWith('/api/')){
    // Same-origin browser requests only; this local demo has no user accounts.
    if(req.headers.origin&&req.headers.origin!==`http://${req.headers.host}`){return send(res,403,{error:'Cross-origin access is disabled'});}
    if(req.method==='GET'&&url.pathname==='/api/state')return send(res,200,read());
    if(req.method==='GET'&&url.pathname==='/api/health')return send(res,200,{ok:true,storage:'sqlite',revision:read().revision});
    if(req.method==='GET'&&url.pathname==='/api/events'){
     if(clients.size>=30)return send(res,503,{error:'Event stream limit reached'});
     res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive'});res.write(`data: ${JSON.stringify({revision:read().revision})}\n\n`);clients.add(res);req.on('close',()=>clients.delete(res));return;
    }
    if(req.method==='POST'&&url.pathname==='/api/commands'){
     if(!String(req.headers['content-type']).startsWith('application/json'))return send(res,415,{error:'Use application/json'});
     let body='';for await(const chunk of req){body+=chunk;if(Buffer.byteLength(body)>16384)return send(res,413,{error:'Request too large'});}
     let input;try{input=JSON.parse(body)}catch{return send(res,400,{error:'Invalid JSON'})}
     if(!input||!Number.isSafeInteger(input.revision)||input.revision<0)return send(res,422,{error:'A non-negative revision is required'});
     const key=req.headers['idempotency-key'];if(typeof key!=='string'||!/^[\w-]{8,100}$/.test(key))return send(res,422,{error:'Idempotency-Key must contain 8–100 letters, digits, underscores or hyphens'});
     const hash=createHash('sha256').update(JSON.stringify(input)).digest('hex');let duplicate=false;
     db.exec('BEGIN IMMEDIATE');try{
      const prior=db.prepare('SELECT hash FROM requests WHERE key=?').get(key);
      if(prior){if(prior.hash!==hash)throw new DomainError('Idempotency key reused with different payload',409);duplicate=true;}
      else{const current=read();if(input.revision!==current.revision)throw new DomainError('Data changed. Refresh and review before retrying.',409);const next=applyCommand(current,input.command,Date.now(),randomUUID);db.prepare('UPDATE state SET document=? WHERE id=1').run(JSON.stringify(next));db.prepare('INSERT INTO requests VALUES(?,?,?)').run(key,hash,next.revision);}
      db.exec('COMMIT');
     }catch(error){db.exec('ROLLBACK');throw error;}
     const current=read();if(!duplicate)for(const stream of clients)stream.write(`data: ${JSON.stringify({revision:current.revision})}\n\n`);
     return send(res,200,{state:current,duplicate});
    }
    return send(res,404,{error:'Unknown API route'});
   }
   if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405);return res.end();}
   const files={'/':'index.html','/index.html':'index.html','/style.css':'style.css','/app.js':'app.js','/domain.js':'domain.js'};const file=files[url.pathname];if(!file){res.writeHead(404);return res.end('Not found');}
   const content=readFileSync(path.join(root,file));res.writeHead(200,{'Content-Type':file.endsWith('.html')?'text/html; charset=utf-8':file.endsWith('.css')?'text/css; charset=utf-8':'text/javascript; charset=utf-8','Cache-Control':'no-store'});res.end(req.method==='HEAD'?undefined:content);
  }catch(error){send(res,error.status||500,{error:error.status?error.message:'Internal server error'});}
 });
 const heartbeat=setInterval(()=>{for(const client of clients)client.write(': heartbeat\n\n')},20000);heartbeat.unref();server.on('close',()=>{clearInterval(heartbeat);db.close()});
 server.shutdown=()=>{for(const client of clients)client.end();server.close();};return server;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){const dir=process.env.SIGNALDESK_DATA_DIR||path.join(path.dirname(fileURLToPath(import.meta.url)),'data');mkdirSync(dir,{recursive:true});const app=createApp({database:path.join(dir,'signaldesk.sqlite')});app.listen(4180,'127.0.0.1',()=>console.log('SignalDesk API + interface: http://localhost:4180/'));}
