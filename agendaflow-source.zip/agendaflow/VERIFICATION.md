# Delivery verification

Verified locally on 2026-10-29:

- Node syntax checks passed for `docs/app.js`, `preview.mjs` and `tests/http.test.mjs`.
- Frontend served successfully at http://localhost:4173 and rendered in a browser.
- Created a fictional booking on 2026-11-02 at 11:00.
- Attempted a second booking at 11:15; overlap was rejected with a visible error.
- Reloaded and selected the booking date; the saved booking remained present.
- Cancelled the booking; status changed to Cancelled, confirmed count to zero and scheduled value to $0.
- Captured the desktop dashboard in `preview.png`.

Not executed locally:

- Java compilation, Java domain/persistence self-tests and HTTP backend integration tests. The available runtime was Java 8 JRE, with no JDK compiler. CI provisions JDK 17 to run these checks after upload.
- Mobile browser execution. Responsive CSS is included; a physical-device check remains recommended.

No deployment to GitHub or public hosting was performed. The preview is local and requires its Node process to remain running.
