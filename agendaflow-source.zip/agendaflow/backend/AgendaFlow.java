import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.*;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

/** Dependency-free Java 17 local portfolio server. Run from the repository root. */
public class AgendaFlow {
    record Service(int minutes, int price) {}
    record Booking(String id, String name, String email, String service, LocalDate date, LocalTime time, String status) {
        Booking cancelled() { return new Booking(id, name, email, service, date, time, "cancelled"); }
        String json() {
            return "{\"id\":"+quote(id)+",\"name\":"+quote(name)+",\"email\":"+quote(email)+
                ",\"service\":"+quote(service)+",\"date\":"+quote(date.toString())+
                ",\"time\":"+quote(time.toString())+",\"status\":"+quote(status)+"}";
        }
    }
    static final Map<String,Service> SERVICES = Map.of("discovery", new Service(30,40), "strategy", new Service(60,120), "design", new Service(45,80));
    static class Validation extends RuntimeException { final int code; Validation(int code,String message){super(message);this.code=code;} }
    static class Store {
        private final Path file;
        private final List<Booking> bookings = new ArrayList<>();
        Store(Path file) throws IOException {
            this.file=file;
            if(Files.exists(file)) {
                for(String line:Files.readAllLines(file, StandardCharsets.UTF_8)) {
                    if(line.isBlank())continue;
                    try {
                        String[] p=line.split("\t",-1);
                        if(p.length!=8)throw new IllegalArgumentException();
                        Booking b=new Booking(p[0],decode(p[1]),decode(p[2]),p[3],LocalDate.parse(p[4]),LocalTime.parse(p[5]),p[6]);
                        if(!SERVICES.containsKey(b.service())||!Set.of("confirmed","cancelled").contains(b.status())||!p[7].equals("v1"))throw new IllegalArgumentException();
                        bookings.add(b);
                    } catch(RuntimeException e) {throw new IOException("Invalid booking data. Restore a valid backup of "+file,e);}
                }
            }
        }
        synchronized String json(){return bookings.stream().map(Booking::json).collect(Collectors.joining(",","[","]"));}
        synchronized Booking create(Map<String,String> input, LocalDateTime now) throws IOException {
            Booking b=validate(input,bookings,now);
            List<Booking> next=new ArrayList<>(bookings);next.add(b);save(next);bookings.add(b);return b;
        }
        synchronized void cancel(String id) throws IOException {
            for(int i=0;i<bookings.size();i++)if(bookings.get(i).id().equals(id)) {
                if(bookings.get(i).status().equals("cancelled"))return;
                List<Booking> next=new ArrayList<>(bookings);next.set(i,next.get(i).cancelled());save(next);bookings.set(i,next.get(i));return;
            }
            throw new Validation(404,"Appointment not found.");
        }
        private void save(List<Booking> next) throws IOException {
            Path absolute=file.toAbsolutePath();Files.createDirectories(absolute.getParent());
            Path temp=Files.createTempFile(absolute.getParent(),"bookings-",".tmp");
            try {
                List<String> lines=next.stream().map(b->String.join("\t",b.id(),encode(b.name()),encode(b.email()),b.service(),b.date().toString(),b.time().toString(),b.status(),"v1")).toList();
                Files.write(temp,lines,StandardCharsets.UTF_8);
                try {Files.move(temp,absolute,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}
                catch(AtomicMoveNotSupportedException e){Files.move(temp,absolute,StandardCopyOption.REPLACE_EXISTING);}
            } finally {Files.deleteIfExists(temp);}
        }
    }
    static Booking validate(Map<String,String> in,List<Booking> existing,LocalDateTime now){
        String name=in.getOrDefault("name","").trim(), email=in.getOrDefault("email","").trim().toLowerCase(Locale.ROOT), service=in.getOrDefault("service","");
        if(name.isEmpty()||name.length()>80||name.chars().anyMatch(Character::isISOControl))throw new Validation(400,"Enter a valid name (up to 80 characters).");
        if(email.length()>120||!email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$"))throw new Validation(400,"Enter a valid email address.");
        if(!SERVICES.containsKey(service))throw new Validation(400,"Choose a valid service.");
        LocalDate date;LocalTime time;
        try {date=LocalDate.parse(in.getOrDefault("date",""));String raw=in.getOrDefault("time","");if(!raw.matches("\\d{2}:\\d{2}"))throw new IllegalArgumentException();time=LocalTime.parse(raw);}
        catch(RuntimeException e){throw new Validation(400,"Choose a valid date and time.");}
        if(!LocalDateTime.of(date,time).isAfter(now))throw new Validation(400,"Choose a future date and time.");
        if(date.getDayOfWeek()==DayOfWeek.SATURDAY||date.getDayOfWeek()==DayOfWeek.SUNDAY)throw new Validation(400,"Please choose Monday through Friday.");
        int start=time.getHour()*60+time.getMinute(),end=start+SERVICES.get(service).minutes();
        if(start<540||end>1080||start%15!=0)throw new Validation(400,"Choose a 15-minute slot within 09:00–18:00.");
        for(Booking b:existing)if(b.status().equals("confirmed")&&b.date().equals(date)){
            int bs=b.time().getHour()*60+b.time().getMinute();
            if(start<bs+SERVICES.get(b.service()).minutes()&&end>bs)throw new Validation(409,"That time overlaps another appointment. Please choose another slot.");
        }
        return new Booking(UUID.randomUUID().toString(),name,email,service,date,time,"confirmed");
    }
    static String encode(String value){return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));}
    static String decode(String value){return new String(Base64.getDecoder().decode(value),StandardCharsets.UTF_8);}
    static String quote(String text){StringBuilder s=new StringBuilder("\"");for(char c:text.toCharArray())switch(c){case '"'->s.append("\\\"");case '\\'->s.append("\\\\");case '\n'->s.append("\\n");case '\r'->s.append("\\r");case '\t'->s.append("\\t");default->{if(c<32)s.append(String.format("\\u%04x",(int)c));else s.append(c);}}return s.append('"').toString();}
    static void send(HttpExchange x,int code,String type,String body)throws IOException{byte[] data=body.getBytes(StandardCharsets.UTF_8);x.getResponseHeaders().set("Content-Type",type+"; charset=utf-8");x.sendResponseHeaders(code,data.length);try(OutputStream out=x.getResponseBody()){out.write(data);}}
    static Map<String,String> form(String body){Map<String,String> map=new HashMap<>();try{for(String field:body.split("&")){String[] pair=field.split("=",2);map.put(URLDecoder.decode(pair[0],StandardCharsets.UTF_8),pair.length>1?URLDecoder.decode(pair[1],StandardCharsets.UTF_8):"");}}catch(IllegalArgumentException e){throw new Validation(400,"Invalid form encoding.");}return map;}
    public static void main(String[] args)throws Exception{
        if(args.length>0&&args[0].equals("--self-test")){selfTest();return;}
        int port=Integer.parseInt(System.getenv().getOrDefault("PORT","8080"));
        Path web=Path.of("docs").toAbsolutePath().normalize();if(!Files.isRegularFile(web.resolve("index.html")))throw new IllegalStateException("Run from the repository root, where docs/index.html exists.");
        Store store=new Store(Path.of("data","bookings.tsv"));
        HttpServer server=HttpServer.create(new InetSocketAddress("127.0.0.1",port),0);
        server.createContext("/",x->{try{
            x.getResponseHeaders().set("X-Content-Type-Options","nosniff");x.getResponseHeaders().set("Referrer-Policy","same-origin");x.getResponseHeaders().set("Cache-Control","no-store");
            String path=x.getRequestURI().getPath(),method=x.getRequestMethod();
            if(path.startsWith("/api/")){
                if(method.equals("POST")||method.equals("DELETE")){
                    String origin=x.getRequestHeaders().getFirst("Origin");String host=x.getRequestHeaders().getFirst("Host");
                    if(host==null||(!host.equals("127.0.0.1:"+port)&&!host.equals("localhost:"+port)))throw new Validation(403,"Invalid host.");
                    if(origin!=null&&!origin.equals("http://"+host))throw new Validation(403,"Cross-origin requests are not allowed.");
                }
                if(path.equals("/api/bookings")){
                    if(method.equals("GET")){send(x,200,"application/json",store.json());return;}
                    if(method.equals("POST")){
                        String ct=x.getRequestHeaders().getFirst("Content-Type");if(ct==null||!ct.startsWith("application/x-www-form-urlencoded"))throw new Validation(415,"Use URL-encoded form data.");
                        byte[] body=x.getRequestBody().readNBytes(4097);if(body.length>4096)throw new Validation(413,"Request too large.");
                        Booking b=store.create(form(new String(body,StandardCharsets.UTF_8)),LocalDateTime.now());send(x,201,"application/json",b.json());return;
                    }
                    x.getResponseHeaders().set("Allow","GET, POST");throw new Validation(405,"Method not allowed.");
                }
                if(path.matches("/api/bookings/[a-zA-Z0-9-]+")&&method.equals("DELETE")){store.cancel(path.substring("/api/bookings/".length()));send(x,200,"application/json","{\"ok\":true}");return;}
                throw new Validation(404,"Endpoint not found.");
            }
            if(!method.equals("GET"))throw new Validation(405,"Method not allowed.");
            // Explicit allowlist prevents exposing runtime data or repository files.
            String file=switch(path){case "/","/index.html"->"index.html";case "/style.css"->"style.css";case "/app.js"->"app.js";default->null;};
            if(file==null){send(x,404,"text/plain","Not found");return;}
            String mime=file.endsWith("css")?"text/css":file.endsWith("js")?"text/javascript":"text/html";
            send(x,200,mime,Files.readString(web.resolve(file)));
        }catch(Validation e){send(x,e.code,"application/json","{\"error\":"+quote(e.getMessage())+"}");}
        catch(Exception e){System.err.println("Request failed: "+e.getClass().getSimpleName());send(x,500,"application/json","{\"error\":\"Server could not save the request. Try again.\"}");}finally{x.close();}});
        server.setExecutor(Executors.newFixedThreadPool(8));server.start();
        Runtime.getRuntime().addShutdownHook(new Thread(()->server.stop(1)));
        System.out.println("AgendaFlow running at http://localhost:"+port+" — Ctrl+C to stop");
    }
    static Map<String,String> sample(String time){return new HashMap<>(Map.of("name","Alex Morgan","email","alex@example.com","service","strategy","date","2030-01-07","time",time));}
    static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    static void rejected(Runnable action,int code){try{action.run();throw new AssertionError("Expected rejection "+code);}catch(Validation e){check(e.code==code,"Wrong response: "+e.code);}}
    static void selfTest()throws Exception{
        LocalDateTime now=LocalDateTime.of(2030,1,1,0,0);Booking first=validate(sample("10:00"),List.of(),now);
        rejected(()->validate(sample("10:30"),List.of(first),now),409);
        check(validate(sample("11:00"),List.of(first),now)!=null,"Adjacent booking must be accepted");
        check(validate(sample("10:00"),List.of(first.cancelled()),now)!=null,"Cancelled slot must be reusable");
        rejected(()->validate(sample("17:30"),List.of(),now),400);
        rejected(()->validate(sample("10:10"),List.of(),now),400);
        Map<String,String> weekend=sample("10:00");weekend.put("date","2030-01-05");rejected(()->validate(weekend,List.of(),now),400);
        rejected(()->validate(sample("10:00"),List.of(),LocalDateTime.of(2031,1,1,0,0)),400);
        Map<String,String> badEmail=sample("10:00");badEmail.put("email","invalid");rejected(()->validate(badEmail,List.of(),now),400);
        Path dir=Files.createTempDirectory("agendaflow-test-");Path file=dir.resolve("bookings.tsv");
        try{
            Store store=new Store(file);Booking b=store.create(sample("10:00"),now);check(new Store(file).json().contains(b.id()),"Persisted booking must reload");
            store.cancel(b.id());check(new Store(file).json().contains("cancelled"),"Cancellation must persist");
            rejected(()->{try{store.cancel("missing");}catch(IOException e){throw new UncheckedIOException(e);}},404);
            check(quote("a\"b\\c\n").equals("\"a\\\"b\\\\c\\n\""),"JSON escaping");
            System.out.println("PASS: overlap, adjacency, cancellation, hours, slot alignment, weekend, past date, email, persistence, missing ID, JSON escaping.");
        }finally{Files.deleteIfExists(file);Files.deleteIfExists(dir);}
    }
}
