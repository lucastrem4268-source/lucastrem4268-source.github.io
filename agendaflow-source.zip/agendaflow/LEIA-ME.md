# AgendaFlow — seu primeiro projeto

Sistema de agendamentos com frontend em HTML, CSS e JavaScript e backend em **Java 17**. A interface e o README principal estão em inglês para facilitar a apresentação internacional.

## Para testar sem instalar Java

Se tiver Node.js, abra um terminal nesta pasta e execute:

```sh
node preview.mjs
```

Abra http://localhost:4173. Este é o modo demonstrativo: os dados ficam no navegador. Os exemplos são criados no próximo dia útil; use o seletor de data para vê-los se hoje for fim de semana.

## Para executar com backend Java

Instale o **JDK 17 ou superior**, abra o terminal nesta pasta e execute:

```sh
java backend/AgendaFlow.java
```

Abra http://localhost:8080. O indicador mostrará “Java server connected”. O banco inicial fica vazio e as reservas são gravadas na pasta `data`.

O computador usado para preparar esta entrega só tinha JRE Java 8, sem compilador. Portanto, o backend precisa passar pelos testes de Java 17 fornecidos antes de ser considerado validado. O GitHub Actions fará isso ao subir o projeto.

## Para colocar no GitHub

1. Crie um repositório público chamado `agendaflow`.
2. Envie o conteúdo desta pasta, incluindo `.github`, sem enviar a pasta `data` gerada na execução.
3. Em **Settings → Pages**, escolha **Deploy from a branch**, branch `main` e pasta `/docs`.
4. Seu link será `https://SEU-USUARIO.github.io/agendaflow/`.
5. Confira a aba **Actions** e os resultados dos testes.

O GitHub Pages executa apenas o frontend demonstrativo. Para usar o backend Java, execute localmente conforme acima. Não há login nesta versão; ela é um projeto local de portfólio.

## O que experimentar

- Criar uma reserva em dia útil entre 09h e 18h.
- Tentar criar outra no mesmo horário e verificar a mensagem de conflito.
- Cancelar, reutilizar o horário e atualizar a página.
- Buscar por nome ou serviço e consultar a lista de clientes.
- Testar no celular ou reduzir a janela.

Próximos projetos sugeridos: painel de vendas/estoque, integração entre serviços e ferramenta com IA. Cada projeto deve ter seu próprio repositório. Estude e personalize o código para explicar suas decisões em entrevistas.
