import http from 'node:http';
import fs from 'node:fs/promises';
const files={'/':['index.html','text/html'],'/index.html':['index.html','text/html'],'/style.css':['style.css','text/css'],'/app.js':['app.js','text/javascript']};
http.createServer(async(req,res)=>{const entry=files[new URL(req.url,'http://localhost').pathname];if(!entry){res.writeHead(404);res.end('Not found');return}try{const content=await fs.readFile(new URL('./docs/'+entry[0],import.meta.url));res.writeHead(200,{'Content-Type':entry[1]+'; charset=utf-8'});res.end(content)}catch{res.writeHead(500);res.end('Unable to read file')}}).listen(4173,'127.0.0.1',()=>console.log('AgendaFlow demo: http://localhost:4173'));
