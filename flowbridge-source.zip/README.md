# FlowBridge — n8n automation workspace

Capture a contact, enqueue a transactional email response, optionally notify a team Telegram chat, and track each attempt. Portfolio project by Lucas Ferreira. **Demo mode never contacts an email or messaging provider.**

## Run

Node **24.x**, no third-party dependencies:

```sh
npm test
npm start
# http://localhost:4190/
```

The server binds to 127.0.0.1. SQLite persists contacts, jobs, event history and incoming event keys. GitHub Pages uses browser-local storage and simulates the queue while the page is open; modules require HTTP rather than file://. The Node worker continues while its process runs, regardless of the browser. Keep a single worker/server process per database.

## Workflow

```mermaid
flowchart LR
  F[Form or POST /api/leads] --> V[Validation + event key]
  V --> S[(Lead and outbox saved atomically)]
  S --> W[Background worker]
  W -->|Demo| D[Simulated result]
  W -->|Configured n8n mode| H[Authenticated n8n webhook]
  H --> C{Channel}
  C --> E[SMTP Email]
  C --> T[Telegram bot]
  E --> A[Provider accepted response]
  T --> A
```

There is no bulk mailing, marketing sequence or external CRM sync in this version. A contact record and an email job are created from each request; entering a Telegram chat creates an additional team notification job. The example emails use reserved example.com addresses. Use your own test recipient when configuring a real provider.

## Configure n8n for actual messages

1. Import `n8n-workflow.json` into your n8n instance. It is inactive and contains no credential references or secrets.
2. In **Incoming job**, configure **Header Auth**, name `X-Relay-Token`, with a secret value stored in n8n credentials. Keep this credential selected; do not change the webhook to unauthenticated.
3. In **Send email**, select an SMTP credential and replace `CHANGE_ME@example.com` with your verified sender. Email is plain text. Set up the sending domain according to your provider's instructions.
4. In **Send Telegram**, select your Telegram bot credential. Supply a team chat ID the bot is allowed to message. Telegram is the messaging channel implemented here; WhatsApp is not included.
5. Test with your own address and chat. Publish/activate the workflow and copy its **production webhook URL**, not the temporary test URL.
6. Configure server-side environment variables `FLOWBRIDGE_MODE=n8n`, `N8N_WEBHOOK_URL` and `N8N_WEBHOOK_TOKEN` (same secret as Header Auth). Restart `npm start`. The interface clearly displays n8n mode before accepting contacts. Use HTTPS for remote n8n. HTTP is permitted only for localhost n8n.
7. Keep SMTP/bot credentials in n8n. Never put them in frontend files, the README or a public repository. The backend never returns its webhook URL/token to the browser. `.env.example` is a reference and is not loaded automatically; set the environment explicitly or use Node's supported env-file option.

**Verification boundary:** The workflow structure, validation code, routes and response contract are tested locally. Import and a real execution in your n8n version still require your n8n instance and provider credentials; they have not been performed in this delivery. Node versions in the template may need updating to match your installation. No real message was sent during verification.

Official references: [Webhook](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.webhook/), [Respond to Webhook](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.respondtowebhook/), [Send Email](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.sendemail/), [Telegram](https://docs.n8n.io/integrations/builtin/app-nodes/n8n-nodes-base.telegram/).

## Delivery semantics

- A unique incoming event key prevents the same form/API event from creating multiple contact/job records. Same key and different payload returns 409. The UI retains its key after an uncertain request; it creates a fresh key after a confirmed success. Repeated intentional submissions create distinct events; email-address deduplication is not implied.
- Claiming a job is persisted **before** contacting the connector. Completion applies to the latest snapshot so new contacts captured during an in-flight request are retained.
- Demo failures automatically retry with exponential delays (2s, 4s) and stop at **3 attempts**. In real mode a connector can explicitly request a safe retry only with HTTP 429 and `{ "notDispatched": true }`. The included n8n workflow does not emit that response.
- A real timeout, error or unexpected response is **ambiguous**, so it goes to `review`, rather than automatically resending. A worker interrupted while processing also recovers into `review` on restart.
- An operator must check n8n/provider executions before manually requeuing a dead/review job. Manual retry resets the attempt counter, leaves history intact and removes the demo failure flag.
- `accepted` means the n8n Email/Telegram node succeeded and the response contract matched. It **does not mean inbox delivery or that a person read the message**. `simulated` is a separate state and never implies a real delivery.
- The n8n template does not implement durable provider-side deduplication. Sending the same job to it externally can duplicate messages. This project does not promise exactly-once delivery.

## API

`GET /api/state` returns `{state, mode}` without secrets. `POST /api/leads` accepts:

```json
{"key":"contact-event-0001","name":"Alex Morgan","email":"alex@example.com","message":"Please contact me about a project.","telegram":"","language":"en","consent":true,"fail":false}
```

`POST /api/retry` accepts `{ "id": "job-id", "confirm": true }`. It can only requeue dead/review jobs. Request bodies are limited to 10 KB. Browser origin checks and static file allowlisting apply. The n8n webhook receives one job at a time and must return `{ "accepted": true, "jobId": "same-job-id" }` only after its sending node succeeds.

## Scope and next steps

This is a local engineering demo, not a hosted production service. No user authentication, multi-tenancy, external CRM, provider delivery callbacks, rate limits or unsubscribe management are implemented. Records are stored in one transactional SQLite snapshot: simple to inspect but not a design for unbounded scale. Browser mode uses Web Locks where available; without them cross-tab writes are best-effort. Production use needs authenticated ingestion, authorization, retention, backups, normalized queue storage, monitoring and hardened deployment. Protect personal contact data and use only recipients who requested the transactional response.

For the portfolio, keep database files out of the static site. Set `FLOWBRIDGE_DATA_DIR` to a private directory outside `site/` when running the backend alongside it.

## Português

Central de integrações com fila de e-mails e mensagens Telegram, histórico, tentativas e fluxo importável no n8n. A demo funciona sem credenciais e **não envia nada externamente**. O backend usa Node 24 e SQLite. Para envios reais, configure SMTP, bot e autenticação de webhook dentro do seu n8n, seguindo os passos acima.
